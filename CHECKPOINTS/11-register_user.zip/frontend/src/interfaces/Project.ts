export interface Project {
   id: number;
   name: string;
   description: string;
   is_finished: boolean;
}
